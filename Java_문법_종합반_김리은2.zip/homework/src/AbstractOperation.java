// AbstractOperation.java
public abstract class AbstractOperation {
    public abstract double operate(int a, int b);
}
